
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Main2014302580015 {
	static final String JDBC_DRIVER="com,mysql.jdbc,Driver";
	static final String DB_URL="jdbc:mysql://localhost/num_1";
	
	//Database credentials
	static final String User="root";
	static final String Pass="h25347";
 public static String name;
 public static String tel;
 public static String mail;
 public static String reseum=null;
 static void count(String url) throws IOException	{	
//String url="http://www.econ.fudan.edu.cn/teacherdetail.php?tid=7";
Document doc= Jsoup.connect(url).get();
//File input =new File(htmlname);
//Document doc=Jsoup.parse(input,"UTF-8");
Elements el1=doc.select("[class=name]");
name=el1.last().text();
System.out.println("������"+name);
//Elements h3=doc.getElementsByTag("h3");
Elements p1=doc.select("p:contains(�绰)");				//������ϵ�绰����Ϣ
Elements p2=doc.select("p:contains(@)");				//���ҵ�������
String include_tel=p1.text();							//�������绰������ַ�������include_tel
String include_mail=p2.text();				//�������������丳���ַ���include_mail
Pattern pa1=Pattern.compile("\\d{3}-\\d{8}");			//ƥ��绰������������ʽ
Pattern pa2=Pattern.compile("\\w{2,15}@\\w{2,10}\\..*\\w{2,3}\\b");			//ƥ����������ַ
Matcher m1=pa1.matcher(include_tel);
Matcher m2=pa2.matcher(include_mail);
if(m1.find()){
	tel=m1.group();
	System.out.println("��ϵ�绰��"+tel);
}
else{
	System.out.println("�绰���룺");
	tel=null;
	
}
if(m2.find()){
	mail=m2.group();	
//	System.out.println("\n");
	System.out.println("�������䣺"+mail);
}
else{
System.out.println("�������䣺");
//System.out.println(xuwei);
mail=null;
	}
reseum=doc.select("[ class=openlist togglecontent]").text();
System.out.println("���˼�飺"+reseum);
String sql;
sql="insert into teachers values(null,\""+name+"\",\""+tel+"\",\""+mail+"\",\""+reseum+"\");";
//System.out.println(sql);
}
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
//HttpRequest request=HttpRequest.get(url);
//String htmlname="test.html";
//if(request.ok()){
//	request.receive(new File(htmlname));
//}
		//Driver name and database url
		String url="http://www.econ.fudan.edu.cn/teacherdetail.php?tid=7";
			Connection conn=null;
			Statement stmt =null;
			try{
			//Register JDBC Driver		
	Class.forName("com.mysql.jdbc.Driver");						//ע��JDBC��������
	//Open a connection				��һ������
	System.out.println("Connection to database.....");
	conn=DriverManager.getConnection(DB_URL,User,Pass);
	//ִ��һ�����
	count(url);
	System.out.println("Creating Statement...");
	stmt=conn.createStatement();
	String sql=null;
	   sql = "select id, name, age, sex from students";
	//sql="insert into teachers values(null,\""+name+"\",\""+tel+"\",\""+mail+"\",\""+reseum+"\");";
//	sql="insert into teachers values(null,\"���ա���,\"207-89722645\",\"897226453@qq.com\",\"�����\");"
//	System.out.println(sql);
	ResultSet rs=stmt.executeQuery(sql);

	//�����ݿ��м�������     			Extract data from result set
		while(rs.next()){
		//Retrieve by column name
		int id =rs.getInt("id");
		int age=rs.getInt("age");
		String name=rs.getString("name");
		String sex=rs.getString("sex");
		
		//Display value
		System.out.println("ID:"+id);
		System.out.println("Age:"+age);
		System.out.println("name:"+name);
		System.out.println("sex:"+sex);
		System.out.println("");
		}
		//��������
		rs.close();
		stmt.close();
		conn.close();
			}catch(SQLException se){
				//Handle errors for JDBC
				se.printStackTrace();
			}catch(Exception e){
				//handle errors for Class,forName
				e.printStackTrace();
			}finally{
				//finally block used to close resources
				try{
					if(stmt!=null)
						stmt.close();
				}catch(SQLException se2){
				}//ʲô������ֱ���׳��쳣
				try{
					if(conn!=null)
						conn.close();
				}catch (SQLException se){
					se.printStackTrace();
				}				//end finally try
			}//end try
			System.out.println("goodbye");
		}			//end main
			 //end FirstEXample
		
	
	}

